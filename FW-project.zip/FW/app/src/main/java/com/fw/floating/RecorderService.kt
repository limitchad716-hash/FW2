package com.fw.floating

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class RecorderService : Service() {
    companion object {
        const val ACTION_START = "fw.rec.start"
        const val ACTION_STOP = "fw.rec.stop"
        @Volatile var isRecording = false
    }

    private class Mux(val m: MediaMuxer, val expected: Int) {
        private var added = 0
        @Volatile var started = false
        private val latch = CountDownLatch(1)
        @Synchronized fun add(f: MediaFormat): Int {
            val i = m.addTrack(f); added++
            if (added == expected) { m.start(); started = true; latch.countDown() }
            return i
        }
        fun write(i: Int, b: ByteBuffer, info: MediaCodec.BufferInfo) {
            latch.await(5, TimeUnit.SECONDS)
            if (started) synchronized(this) { try { m.writeSampleData(i, b, info) } catch (_: Exception) {} }
        }
        fun finish() { try { if (started) m.stop() } catch (_: Exception) {}; try { m.release() } catch (_: Exception) {} }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var arec: AudioRecord? = null
    private var mux: Mux? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var vt: Thread? = null
    private var at: Thread? = null
    private var t0 = 0L
    @Volatile private var running = false
    private val stopping = AtomicBoolean(false)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACTION_START -> if (!isRecording) start(i)
            ACTION_STOP -> stop()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        ensureChannel()
        val pi = PendingIntent.getService(this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "fw").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("FW is recording").setContentText("Tap Stop para i-save")
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", pi).build())
            .setOngoing(true).build()
    }

    @Suppress("DEPRECATION")
    private fun start(i: Intent) {
        stopping.set(false)
        startForeground(2, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val code = i.getIntExtra("code", 0)
        val data: Intent? = i.getParcelableExtra("data")
        ui.postDelayed({
            try { setup(code, data!!) } catch (e: Exception) {
                Toast.makeText(this, "Record failed: ${e.message}", Toast.LENGTH_LONG).show()
                isRecording = true; stopping.set(false); stop()
            }
        }, 500)
    }

    private fun even(v: Float) = (v.toInt() / 2) * 2

    private fun setup(code: Int, data: Intent) {
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, ui)

        val dsp = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val dm = DisplayMetrics(); dsp.getRealMetrics(dm)
        val sc = minOf(1f, Prefs.res(this).toFloat() / minOf(dm.widthPixels, dm.heightPixels))
        val w = even(dm.widthPixels * sc); val h = even(dm.heightPixels * sc)

        val req = Prefs.fps(this)
        val vc = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .firstOrNull { it.isEncoder && it.supportedTypes.contains("video/avc") }
            ?.getCapabilitiesForType("video/avc")?.videoCapabilities
        val fps = listOf(req, 90, 60, 30).filter { it <= req }.distinct()
            .firstOrNull { vc == null || vc.areSizeAndRateSupported(w, h, it.toDouble()) } ?: 30
        val br = (w.toLong() * h * fps * 0.09).toInt().coerceIn(2_000_000, 50_000_000)

        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, br)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val ve = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        ve.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = ve.createInputSurface()
        venc = ve

        var hasAudio = false
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
                val minBuf = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                arec = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
                    .setBufferSizeInBytes(minBuf * 4).build()
                val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                }
                aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).also {
                    it.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                }
                hasAudio = true
            } catch (e: Exception) { arec?.release(); arec = null; aenc?.release(); aenc = null }
        }

        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "FW_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FW")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        pfd = contentResolver.openFileDescriptor(uri!!, "rw")
        val muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val mx = Mux(muxer, if (hasAudio) 2 else 1); mux = mx

        t0 = System.nanoTime() / 1000
        ve.start()
        vd = p.createVirtualDisplay("FW", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
        running = true; isRecording = true

        vt = Thread { videoLoop(ve, mx) }.also { it.start() }
        if (hasAudio) {
            aenc!!.start(); arec!!.startRecording()
            at = Thread { audioLoop(aenc!!, arec!!, mx) }.also { it.start() }
        }
        val note = if (dsp.refreshRate + 1 < fps) " (screen ${dsp.refreshRate.toInt()}Hz lang)" else ""
        Toast.makeText(this, "REC ${w}x$h @${fps}fps${if (hasAudio) " + audio" else " (walang audio)"}$note", Toast.LENGTH_LONG).show()
    }

    private fun videoLoop(e: MediaCodec, mx: Mux) {
        val info = MediaCodec.BufferInfo(); var track = -1; var last = 0L
        try {
            while (true) {
                val i = e.dequeueOutputBuffer(info, 10000)
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) track = mx.add(e.outputFormat)
                else if (i >= 0) {
                    val b = e.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && track >= 0) {
                        info.presentationTimeUs = maxOf(info.presentationTimeUs - t0, last).also { last = it }
                        b.position(info.offset); b.limit(info.offset + info.size)
                        mx.write(track, b, info)
                    }
                    e.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
        } catch (_: Exception) {}
    }

    private fun audioLoop(e: MediaCodec, rec: AudioRecord, mx: Mux) {
        val info = MediaCodec.BufferInfo(); var track = -1; var last = 0L; var eos = false
        try {
            while (true) {
                if (!eos) {
                    val ii = e.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val b = e.getInputBuffer(ii)!!; b.clear()
                        val pts = (System.nanoTime() / 1000 - t0).coerceAtLeast(0)
                        if (!running) { e.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eos = true }
                        else {
                            val n = rec.read(b, b.capacity())
                            e.queueInputBuffer(ii, 0, if (n > 0) n else 0, pts, 0)
                        }
                    }
                }
                while (true) {
                    val oi = e.dequeueOutputBuffer(info, 0)
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) break
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mx.add(e.outputFormat); continue }
                    if (oi < 0) continue
                    val ob = e.getOutputBuffer(oi)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && track >= 0) {
                        info.presentationTimeUs = maxOf(info.presentationTimeUs, last).also { last = it }
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        mx.write(track, ob, info)
                    }
                    e.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        } catch (_: Exception) {}
    }

    private fun stop() {
        if (!isRecording && venc == null) { stopSelf(); return }
        if (!stopping.compareAndSet(false, true)) return
        running = false
        Thread {
            try { vd?.release() } catch (_: Exception) {}
            try { venc?.signalEndOfInputStream() } catch (_: Exception) {}
            try { vt?.join(4000); at?.join(4000) } catch (_: Exception) {}
            mux?.finish()
            try { venc?.stop() } catch (_: Exception) {}; try { venc?.release() } catch (_: Exception) {}
            try { aenc?.stop() } catch (_: Exception) {}; try { aenc?.release() } catch (_: Exception) {}
            try { arec?.stop() } catch (_: Exception) {}; try { arec?.release() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            uri?.let { try { contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) } catch (_: Exception) {} }
            try { projection?.stop() } catch (_: Exception) {}
            isRecording = false
            ui.post {
                Toast.makeText(this, "Na-save sa Movies/FW", Toast.LENGTH_LONG).show()
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
        }.start()
    }
}
