package com.fw.floating

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val BG = 0xFF0F1226.toInt()
    private val ACC = 0xFF7C4DFF.toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(30))
        }
        col.addView(text("FW", 38f, true))
        col.addView(text("Floating Windows", 15f, false, 0xFFB8BCD9.toInt()))
        col.addView(space(24))
        col.addView(button("▶  START FLOATING WINDOWS", ACC) { startFloating() })
        col.addView(space(10))
        col.addView(button("⏺  Record Screen (start / stop)", 0xFFD32F2F.toInt()) {
            startActivity(Intent(this, ProjectionActivity::class.java))
        })
        col.addView(space(10))
        col.addView(button("■  Stop Floating Windows", 0xFF2A2F55.toInt()) {
            stopService(Intent(this, FloatingService::class.java))
        })
        col.addView(space(22))
        col.addView(radio("Gilid ng panel", listOf("Kaliwa", "Kanan"), Prefs.side(this)) { Prefs.set(this, "side", it) })
        col.addView(radio("Record FPS", listOf("60", "90", "120"), listOf(60, 90, 120).indexOf(Prefs.fps(this))) {
            Prefs.set(this, "fps", listOf(60, 90, 120)[it])
        })
        col.addView(radio("Record Resolution", listOf("480p", "720p", "1080p"), listOf(480, 720, 1080).indexOf(Prefs.res(this))) {
            Prefs.set(this, "res", listOf(480, 720, 1080)[it])
        })
        col.addView(radio("Auto-scroll timer (min)", listOf("5", "10", "20", "30", "60"), listOf(5, 10, 20, 30, 60).indexOf(Prefs.autoMin(this))) {
            Prefs.set(this, "auto", listOf(5, 10, 20, 30, 60)[it])
        })
        col.addView(space(12))
        col.addView(text("Tip: i-tap o i-swipe papasok ang purple na handle sa gilid para lumabas ang FB / YT / TikTok. Mag-apply ang FPS/resolution sa susunod na record; ang gilid sa susunod na start.", 12f, false, 0xFF8A8FB5.toInt()))
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
    }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "I-allow ang 'Display over other apps' para sa FW", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        stopService(Intent(this, FloatingService::class.java))
        startForegroundService(Intent(this, FloatingService::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun text(t: String, size: Float, bold: Boolean, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun button(t: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54))
        setOnClickListener { click() }
    }

    private fun radio(title: String, opts: List<String>, sel: Int, pick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        box.addView(text(title, 13f, true, 0xFFB8BCD9.toInt()))
        val g = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; gravity = Gravity.START }
        opts.forEachIndexed { i, o ->
            g.addView(RadioButton(this).apply { id = View.generateViewId(); text = o; setTextColor(Color.WHITE); isChecked = i == sel })
        }
        g.setOnCheckedChangeListener { grp, id -> pick(grp.indexOfChild(grp.findViewById(id))) }
        box.addView(g)
        return box
    }
}
