package com.fw.floating

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("fw", 0)
    fun fps(c: Context) = sp(c).getInt("fps", 60)
    fun res(c: Context) = sp(c).getInt("res", 720)
    fun autoMin(c: Context) = sp(c).getInt("auto", 10)
    fun side(c: Context) = sp(c).getInt("side", 1) // 1 = kanan, 0 = kaliwa
    fun set(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.ensureChannel() {
    val nm = getSystemService(NotificationManager::class.java)
    if (nm.getNotificationChannel("fw") == null)
        nm.createNotificationChannel(NotificationChannel("fw", "FW", NotificationManager.IMPORTANCE_LOW))
}
