package com.fw.floating

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.webkit.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

private const val JS_AUTO = """
(function(){
 if(window.__fwInit) return; window.__fwInit=true;
 function scroller(v){ var e=v; while(e && e!==document.body){ var s=getComputedStyle(e);
   if((s.overflowY=='auto'||s.overflowY=='scroll'||s.overflowY=='overlay') && e.scrollHeight>e.clientHeight+10) return e; e=e.parentElement;} return null; }
 function next(v){
   var done=false;
   var sels=['#navigation-button-down button','button[aria-label="Next video"]','[data-e2e="arrow-right"]','.ytp-next-button','button[aria-label*="Next"]'];
   for(var i=0;i<sels.length&&!done;i++){ var b=document.querySelector(sels[i]); if(b){ b.click(); done=true; } }
   if(!done){
     var s=scroller(v)||document.scrollingElement||document.body;
     try{ s.scrollBy({top:window.innerHeight,behavior:'smooth'}); }catch(e){ s.scrollTop+=window.innerHeight; }
     var ev={key:'ArrowDown',code:'ArrowDown',keyCode:40,which:40,bubbles:true};
     document.dispatchEvent(new KeyboardEvent('keydown',ev));
   }
 }
 setInterval(function(){
   if(!window.__fwAuto) return;
   var vs=document.querySelectorAll('video');
   for(var i=0;i<vs.length;i++){ var v=vs[i]; var r=v.getBoundingClientRect();
     if(r.bottom<=0||r.top>=innerHeight||!v.duration||isNaN(v.duration)||v.duration<2) continue;
     if(v.currentTime<1){ v.__fwAdv=false; }
     if(!v.__fwAdv && (v.ended || v.currentTime>=v.duration-0.4)){ v.__fwAdv=true; next(v); break; }
   }
 },400);
 var __kill=['not now','maybe later','no thanks','continue in browser','continue on web','stay on web','hindi ngayon','later','use browser'];
 setInterval(function(){
   var els=document.querySelectorAll('button,a,div[role="button"]');
   for(var i=0;i<els.length;i++){ var t=(els[i].innerText||'').trim().toLowerCase();
     if(t.length<24 && __kill.indexOf(t)>=0 && !els[i].__fwk){ els[i].__fwk=true; try{ els[i].click(); }catch(e){} } }
 },2000);
})();
"""

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private val windows = mutableListOf<AppWindow>()
    private var handleY = -1
    private val dockRight: Boolean get() = Prefs.side(this) == 1
    private val OV = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun sw() = resources.displayMetrics.widthPixels
    private fun sh() = resources.displayMetrics.heightPixels

    private fun chromeUa(): String = try {
        WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "")
    } catch (_: Exception) { UA }

    private fun statusH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }
    private fun navH(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }
    private fun minY() = statusH() + dp(8)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ensureChannel()
        val pi = PendingIntent.getService(this, 3, Intent(this, FloatingService::class.java).setAction("fw.stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "fw").setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("FW is running").setContentText("Swipe the purple edge handle")
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", pi).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        addHandle()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "fw.stop") stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        windows.toList().forEach { it.destroy() }
        try { handle?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        try { settingsView?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------- Edge handle ----------
    private fun addHandle() {
        val r = dp(10).toFloat()
        val bar = View(this).apply {
            background = GradientDrawable().apply {
                setColor(0xE67C4DFF.toInt())
                cornerRadii = if (dockRight) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
        }
        val box = FrameLayout(this).apply {
            addView(bar, FrameLayout.LayoutParams(dp(10), dp(80), Gravity.CENTER_VERTICAL or (if (dockRight) Gravity.END else Gravity.START)))
        }
        if (handleY < 0) handleY = sh() / 3
        val lp = WindowManager.LayoutParams(dp(30), dp(100), OV,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or (if (dockRight) Gravity.END else Gravity.START); x = 0; y = handleY
        }
        var downX = 0f; var downY = 0f; var startY = 0; var dragged = false; var opened = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        box.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = lp.y; dragged = false; opened = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX) * (if (dockRight) -1 else 1)
                    val dy = e.rawY - downY
                    if (!opened && dx > dp(24) && dx > Math.abs(dy)) { opened = true; v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); openPanel() }
                    else if (!opened && Math.abs(dy) > slop) {
                        dragged = true
                        lp.y = (startY + dy).toInt().coerceIn(dp(24), sh() - dp(140)); handleY = lp.y
                        try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!dragged && !opened) openPanel()
            }
            true
        }
        wm.addView(box, lp); handle = box; handleLp = lp
    }

    private fun showHandle(show: Boolean) {
        val h = handle ?: return
        if (show) { h.visibility = View.VISIBLE; h.animate().alpha(1f).setDuration(200).start() }
        else h.animate().alpha(0f).setDuration(120).withEndAction { h.visibility = View.INVISIBLE }.start()
    }

    // ---------- Side panel ----------
    private fun circle(label: String, color: Int, stroke: Int = 0, click: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); if (stroke != 0) setStroke(dp(2), stroke) }
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        setOnClickListener {
            animate().scaleX(.85f).scaleY(.85f).setDuration(70).withEndAction {
                animate().scaleX(1f).scaleY(1f).setDuration(120).setInterpolator(OvershootInterpolator()).start(); click()
            }.start()
        }
    }

    private fun openPanel() {
        if (panel != null) return
        showHandle(false)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8)); elevation = dp(8).toFloat()
            background = GradientDrawable().apply { setColor(0xF0151A2E.toInt()); cornerRadius = dp(28).toFloat() }
        }
        col.addView(circle("f", 0xFF1877F2.toInt()) { closePanel(); open("Facebook", "https://m.facebook.com") })
        col.addView(circle("▶", 0xFFFF0000.toInt()) { closePanel(); open("YouTube", "https://m.youtube.com") })
        col.addView(circle("♪", 0xFF111111.toInt(), 0xFF25F4EE.toInt()) { closePanel(); open("TikTok", "https://www.tiktok.com") })
        col.addView(circle(if (RecorderService.isRecording) "■" else "●", 0xFFD32F2F.toInt()) {
            closePanel(); startActivity(Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        col.addView(circle("⚙", 0xFF2A2F55.toInt()) {
            closePanel(); openSettings()
        })
        col.addView(circle("✕", 0xFF444444.toInt()) { stopSelf() })
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, OV,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or (if (dockRight) Gravity.END else Gravity.START)
            x = dp(4); y = (handleY - dp(120)).coerceIn(dp(24), (sh() - dp(400)).coerceAtLeast(dp(24)))
        }
        col.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel(); false }
        col.alpha = 0f; col.translationX = dp(90).toFloat() * (if (dockRight) 1 else -1)
        wm.addView(col, lp); panel = col
        col.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closePanel() {
        val p = panel ?: return
        panel = null
        p.animate().alpha(0f).translationX(dp(90).toFloat() * (if (dockRight) 1 else -1)).setDuration(180)
            .withEndAction { try { wm.removeViewImmediate(p) } catch (_: Exception) {} }.start()
        showHandle(true)
    }

    // ---------- Floating settings ----------
    private var settingsView: View? = null

    private fun rebuildHandle() {
        try { handle?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        handle = null; addHandle()
    }

    private fun curVal(key: String) = when (key) {
        "fps" -> Prefs.fps(this); "res" -> Prefs.res(this); "auto" -> Prefs.autoMin(this); else -> Prefs.side(this)
    }

    private fun chipRow(title: String, labels: List<String>, values: List<Int>, key: String, after: () -> Unit = {}): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(4)) }
        box.addView(TextView(this).apply { text = title; setTextColor(0xFFB8BCD9.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = mutableListOf<TextView>()
        fun refresh() {
            val cur = curVal(key)
            chips.forEachIndexed { i, c -> (c.background as GradientDrawable).setColor(if (values[i] == cur) 0xFF7C4DFF.toInt() else 0xFF2A2F55.toInt()) }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFF2A2F55.toInt()) }
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) }
            }
            c.setOnClickListener { Prefs.set(this, key, values[i]); refresh(); after() }
            chips += c; row.addView(c)
        }
        refresh(); box.addView(row)
        return box
    }

    private fun closeSettings() {
        val v = settingsView ?: return
        settingsView = null
        v.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150)
            .withEndAction { try { wm.removeViewImmediate(v) } catch (_: Exception) {} }.start()
    }

    private fun openSettings() {
        if (settingsView != null) return
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); elevation = dp(10).toFloat()
            background = GradientDrawable().apply { setColor(0xF5151A2E.toInt()); cornerRadius = dp(20).toFloat() }
        }
        col.addView(TextView(this).apply { text = "⚙  Settings"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD })
        col.addView(chipRow("Gilid ng panel", listOf("Kaliwa", "Kanan"), listOf(0, 1), "side") { rebuildHandle() })
        col.addView(chipRow("Record FPS", listOf("60", "90", "120"), listOf(60, 90, 120), "fps"))
        col.addView(chipRow("Record Resolution", listOf("480p", "720p", "1080p"), listOf(480, 720, 1080), "res"))
        col.addView(TextView(this).apply {
            text = "Done"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xFF7C4DFF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) }
            setOnClickListener { closeSettings() }
        })
        val lp = WindowManager.LayoutParams((sw() * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, OV,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        col.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closeSettings(); false }
        col.alpha = 0f; col.scaleX = 0.9f; col.scaleY = 0.9f
        wm.addView(col, lp); settingsView = col
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun open(title: String, url: String) {
        val w = AppWindow(title, url, windows.size)
        windows += w; w.show()
    }

    // ---------- Floating app window ----------
    inner class AppWindow(private val title: String, private val startUrl: String, private val index: Int) {
        private val lp = WindowManager.LayoutParams(0, 0, OV,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        private lateinit var root: FrameLayout
        private lateinit var web: WebView
        private lateinit var autoBtn: TextView
        private lateinit var bar: LinearLayout
        private lateinit var holder: FrameLayout
        private lateinit var grip: TextView
        private lateinit var restoreBtn: TextView
        private lateinit var autoMenu: LinearLayout
        private var immersive = false
        private var focusable = true
        private var autoFull = false
        private var yBeforeIme = -1
        private var autoOn = false
        private var fullscreen = false
        private var saved = IntArray(4)
        private var anim: ValueAnimator? = null
        private var customView: View? = null
        private var customCb: WebChromeClient.CustomViewCallback? = null
        private val autoStop = Runnable { setAuto(false) }

        private fun setFocusable(on: Boolean) {
            if (on == focusable || !root.isAttachedToWindow) return
            focusable = on
            lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
            if (on) ui.postDelayed({ kick() }, 150)
        }

        private fun kick() {
            if (!::web.isInitialized) return
            web.requestFocus()
            web.evaluateJavascript("(function(){var a=document.activeElement;return !!a&&(a.tagName=='INPUT'||a.tagName=='TEXTAREA'||a.isContentEditable);})()") { r ->
                if (r == "true") {
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.restartInput(web); imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT)
                }
            }
        }

        private fun onIme(h: Int) {
            if (fullscreen) return
            if (h > 0) {
                if (yBeforeIme < 0) yBeforeIme = lp.y
                val ny = (sh() + navH() - h - lp.height).coerceAtLeast(minY())
                if (ny < lp.y) { lp.y = ny; try { wm.updateViewLayout(root, lp) } catch (_: Exception) {} }
            } else if (yBeforeIme >= 0) {
                lp.y = yBeforeIme; yBeforeIme = -1
                try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
            }
        }

        private fun btn(t: String, click: () -> Unit) = TextView(this@FloatingService).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)); setOnClickListener { click() }
        }

        @android.annotation.SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
        fun show() {
            val ctx = this@FloatingService
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            lp.gravity = Gravity.TOP or Gravity.START
            lp.width = (sw() * 0.86f).toInt(); lp.height = (sh() * 0.55f).toInt()
            lp.x = (sw() - lp.width) / 2 + dp(18) * (index % 4); lp.y = minY() + dp(30) + dp(26) * (index % 4)

            root = object : FrameLayout(ctx) {
                override fun dispatchTouchEvent(e: MotionEvent): Boolean {
                    if (e.action == MotionEvent.ACTION_OUTSIDE) { setFocusable(false); return false }
                    if (e.action == MotionEvent.ACTION_DOWN) {
                        setFocusable(true)
                        if (::autoMenu.isInitialized && autoMenu.visibility == View.VISIBLE) {
                            val r = Rect(); autoMenu.getHitRect(r)
                            if (e.y > dp(40) && !r.contains(e.x.toInt(), e.y.toInt())) autoMenu.visibility = View.GONE
                        }
                    }
                    return super.dispatchTouchEvent(e)
                }
                override fun dispatchKeyEvent(e: KeyEvent): Boolean {
                    if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) onBack(); return true }
                    return super.dispatchKeyEvent(e)
                }
            }
            root.setBackgroundColor(0xFF0F1226.toInt())
            if (Build.VERSION.SDK_INT >= 30) {
                root.setOnApplyWindowInsetsListener { _, ins ->
                    onIme(ins.getInsets(WindowInsets.Type.ime()).bottom); ins
                }
            }
            root.elevation = dp(12).toFloat()
            root.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat()) }
            }
            root.clipToOutline = true

            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(0xFF1E2140.toInt()) }
            bar.addView(TextView(ctx).apply {
                text = title; setTextColor(0xFFDDDFF5.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL
            })
            autoBtn = btn("⏭") { toggleAutoMenu() }
            bar.addView(autoBtn)
            bar.addView(btn("−") { scaleTo(0.85f) })
            bar.addView(btn("+") { scaleTo(1.18f) })
            bar.addView(btn("▼") { setImmersive(true) })
            bar.addView(btn("□") { toggleFull() })
            bar.addView(btn("✕") { close() })
            col.addView(bar, LinearLayout.LayoutParams(-1, dp(36)))

            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
            bar.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                    MotionEvent.ACTION_MOVE -> if (!fullscreen) {
                        lp.x = (sx + e.rawX - dx).toInt().coerceIn(-lp.width + dp(80), sw() - dp(80))
                        lp.y = (sy + e.rawY - dy).toInt().coerceIn(minY(), sh() - dp(60))
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                }
                true
            }

            web = WebView(ctx).apply {
                setBackgroundColor(Color.BLACK)
                isFocusable = true; isFocusableInTouchMode = true
                settings.apply {
                    javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false
                    setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
                    useWideViewPort = true; loadWithOverviewMode = true; userAgentString = chromeUa()
                    javaScriptCanOpenWindowsAutomatically = true
                }
                if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                    try { WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, emptySet()) } catch (_: Exception) {}
                }
                overScrollMode = View.OVER_SCROLL_NEVER
                isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        val s = r.url.scheme ?: return true
                        return !(s == "http" || s == "https")
                    }
                    override fun onPageFinished(v: WebView, u: String?) {
                        v.evaluateJavascript(JS_AUTO, null)
                        CookieManager.getInstance().flush()
                        v.evaluateJavascript("window.__fwAuto=$autoOn;", null)
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                        customView = v; customCb = cb
                        root.addView(v, FrameLayout.LayoutParams(-1, -1))
                        if (!fullscreen) { autoFull = true; toggleFull() }
                    }
                    override fun onHideCustomView() { hideCustom() }
                }
                loadUrl(startUrl)
            }
            val vw0 = minOf(sw(), sh())
            holder = FrameLayout(ctx).apply { setBackgroundColor(Color.BLACK); clipChildren = true }
            holder.addView(web, FrameLayout.LayoutParams(vw0, vw0))
            holder.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
                val hw = r - l; val hh = b - t
                web.post { applyScale(hw, hh) }
            }
            col.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
            root.addView(col, FrameLayout.LayoutParams(-1, -1))

            grip = TextView(ctx).apply { text = "◢"; setTextColor(0x99FFFFFF.toInt()); textSize = 16f; gravity = Gravity.CENTER }
            root.addView(grip, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.END))
            restoreBtn = TextView(ctx).apply {
                text = "▲"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; alpha = 0.65f; visibility = View.GONE
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC1E2140.toInt()) }
                setOnClickListener { setImmersive(false) }
            }
            root.addView(restoreBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.END).apply { topMargin = statusH() + dp(6); marginEnd = dp(8) })
            autoMenu = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL; visibility = View.GONE; elevation = dp(6).toFloat()
                setPadding(dp(10), dp(8), dp(10), dp(10))
                background = GradientDrawable().apply { setColor(0xF2151A2E.toInt()); cornerRadius = dp(14).toFloat() }
            }
            root.addView(autoMenu, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(40); marginEnd = dp(6) })
            var rx = 0f; var ry = 0f; var rw = 0; var rh = 0
            grip.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = lp.width; rh = lp.height }
                    MotionEvent.ACTION_MOVE -> if (!fullscreen) {
                        lp.width = (rw + e.rawX - rx).toInt().coerceIn(dp(250), maxOf(dp(250), sw() - lp.x.coerceAtLeast(0)))
                        lp.height = (rh + e.rawY - ry).toInt().coerceIn(dp(200), maxOf(dp(200), sh() - lp.y.coerceAtLeast(0)))
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                }
                true
            }

            root.alpha = 0f; root.scaleX = 0.8f; root.scaleY = 0.8f
            wm.addView(root, lp)
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.1f)).start()
        }

        private fun applyScale(hw: Int, hh: Int) {
            if (hw <= 0 || hh <= 0 || !::web.isInitialized) return
            val vw = minOf(sw(), sh())
            val sc = hw.toFloat() / vw
            val vh = (hh / sc).toInt()
            val p = web.layoutParams
            if (p.width != vw || p.height != vh) { p.width = vw; p.height = vh; web.layoutParams = p }
            web.pivotX = 0f; web.pivotY = 0f; web.scaleX = sc; web.scaleY = sc
        }

        private fun realSize(): IntArray {
            val d = getSystemService(DisplayManager::class.java).getDisplay(android.view.Display.DEFAULT_DISPLAY)
            val m = DisplayMetrics(); d.getRealMetrics(m)
            return intArrayOf(m.widthPixels, m.heightPixels)
        }

        private fun setImmersive(on: Boolean) {
            if (on == immersive) return
            immersive = on
            autoMenu.visibility = View.GONE
            if (on) {
                if (!fullscreen) saved = intArrayOf(lp.x, lp.y, lp.width, lp.height)
                bar.visibility = View.GONE; grip.visibility = View.GONE; restoreBtn.visibility = View.VISIBLE
                val sz = realSize(); animateBounds(0, 0, sz[0], sz[1])
            } else {
                bar.visibility = View.VISIBLE; grip.visibility = View.VISIBLE; restoreBtn.visibility = View.GONE
                if (fullscreen) animateBounds(0, minY(), sw(), sh() - minY())
                else animateBounds(saved[0], saved[1], saved[2], saved[3])
            }
        }

        private fun toggleAutoMenu() {
            if (autoMenu.visibility == View.VISIBLE) { autoMenu.visibility = View.GONE; return }
            val ctx = this@FloatingService
            autoMenu.removeAllViews()
            autoMenu.addView(TextView(ctx).apply {
                text = if (autoOn) "Auto-scroll: ON" else "Auto-scroll pag tapos ang video"
                setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            })
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
            val cur = Prefs.autoMin(ctx)
            listOf(5, 10, 20, 30, 60).forEach { m ->
                row.addView(TextView(ctx).apply {
                    text = "$m"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                    background = GradientDrawable().apply {
                        cornerRadius = dp(10).toFloat()
                        setColor(if (autoOn && m == cur) 0xFF00A152.toInt() else 0xFF2A2F55.toInt())
                    }
                    layoutParams = LinearLayout.LayoutParams(dp(40), dp(38)).apply { setMargins(dp(2), 0, dp(2), 0) }
                    setOnClickListener { Prefs.set(ctx, "auto", m); setAuto(true); autoMenu.visibility = View.GONE }
                })
            }
            autoMenu.addView(row)
            autoMenu.addView(TextView(ctx).apply { text = "minuto (haba ng auto-scroll)"; setTextColor(0xFF8A8FB5.toInt()); textSize = 10f; setPadding(0, dp(4), 0, 0) })
            if (autoOn) autoMenu.addView(TextView(ctx).apply {
                text = "■  Stop"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFFD32F2F.toInt()) }
                layoutParams = LinearLayout.LayoutParams(-1, dp(36)).apply { topMargin = dp(8) }
                setOnClickListener { setAuto(false); autoMenu.visibility = View.GONE }
            })
            autoMenu.alpha = 0f; autoMenu.visibility = View.VISIBLE
            autoMenu.animate().alpha(1f).setDuration(150).start()
        }

        private fun animateBounds(x: Int, y: Int, w: Int, h: Int) {
            anim?.cancel()
            val x0 = lp.x; val y0 = lp.y; val w0 = lp.width; val h0 = lp.height
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 240; interpolator = DecelerateInterpolator()
                addUpdateListener {
                    val f = it.animatedValue as Float
                    lp.x = (x0 + (x - x0) * f).toInt(); lp.y = (y0 + (y - y0) * f).toInt()
                    lp.width = (w0 + (w - w0) * f).toInt(); lp.height = (h0 + (h - h0) * f).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (_: Exception) { cancel() }
                }
                start()
            }
        }

        private fun scaleTo(f: Float) {
            if (fullscreen || immersive) return
            val nw = (lp.width * f).toInt().coerceIn(dp(250), sw())
            val nh = (lp.height * f).toInt().coerceIn(dp(200), sh())
            animateBounds((lp.x - (nw - lp.width) / 2).coerceIn(0, (sw() - nw).coerceAtLeast(0)),
                (lp.y - (nh - lp.height) / 2).coerceIn(minY(), maxOf(minY(), sh() - nh)), nw, nh)
        }

        private fun toggleFull() {
            if (immersive) return
            if (!fullscreen) {
                saved = intArrayOf(lp.x, lp.y, lp.width, lp.height); fullscreen = true
                animateBounds(0, minY(), sw(), sh() - minY())
            } else {
                fullscreen = false; animateBounds(saved[0], saved[1], saved[2], saved[3])
            }
        }

        private fun setAuto(on: Boolean) {
            autoOn = on; ui.removeCallbacks(autoStop)
            if (on) ui.postDelayed(autoStop, Prefs.autoMin(this@FloatingService) * 60_000L)
            autoBtn.setTextColor(if (on) 0xFF00E676.toInt() else Color.WHITE)
            web.evaluateJavascript("window.__fwAuto=$on;", null)
            Toast.makeText(this@FloatingService, if (on) "Auto-scroll ON (${Prefs.autoMin(this@FloatingService)} min)" else "Auto-scroll OFF", Toast.LENGTH_SHORT).show()
        }

        private fun hideCustom() {
            customView?.let { root.removeView(it) }; customView = null
            customCb?.onCustomViewHidden(); customCb = null
            if (autoFull) { autoFull = false; if (fullscreen) toggleFull() }
        }

        private fun onBack() {
            if (customView != null) hideCustom()
            else if (web.canGoBack()) web.goBack()
            else close()
        }

        fun close() {
            windows.remove(this)
            ui.removeCallbacks(autoStop)
            root.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(180).withEndAction {
                destroy()
                if (windows.isEmpty()) openPanel() // balik sa mga icon
            }.start()
        }

        fun destroy() {
            ui.removeCallbacks(autoStop); anim?.cancel()
            try { wm.removeViewImmediate(root) } catch (_: Exception) {}
            try { web.stopLoading(); web.loadUrl("about:blank"); web.destroy() } catch (_: Exception) {}
        }
    }
}
